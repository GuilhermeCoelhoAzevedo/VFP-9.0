* Hides all _memberdata property values that are
* used for Intellisense ~150kb
*#DEFINE XFC_NOMEMBERDATA

* Hides all the advanced drawing functionality 
* (Bezier curves, GraphicsPath, etc...) ~130kb
*#DEFINE GDIPX_SIMPLEDRAWING 

* Hides all the advanced image functionality 
* (ColorMatrix, Metafile, etc...) ~70kb
*#DEFINE GDIPX_SIMPLEIMAGING

